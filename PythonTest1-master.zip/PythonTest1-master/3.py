list = [2,4,5,6,3,4]

for n in list:
 print(n)
 print('Printed')