while True:
 print('Something')

print('Done')